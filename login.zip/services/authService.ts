
import { UserSession } from '../types';

export const authService = {
  login: async (username: string, password: string): Promise<UserSession> => {
    // Para conectar com seu PostgreSQL, você precisará de uma API (Node.js, PHP, Python, etc.)
    // Exemplo de integração real:
    /*
    const response = await fetch('http://seu-servidor.com/api/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password })
    });
    if (!response.ok) throw new Error('Incorreto');
    return await response.json();
    */

    // Simulação para o preview funcionar (usuário: admin, senha: 123)
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        if (username === 'admin' && password === '123') {
          resolve({ id: '1', email: username });
        } else {
          reject(new Error('Usuário ou senha incorretos'));
        }
      }, 1000);
    });
  }
};
