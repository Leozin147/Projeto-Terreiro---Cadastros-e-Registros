
import React from 'react';
import { UserSession } from '../types';

interface DashboardPlaceholderProps {
  user: UserSession;
  onLogout: () => void;
}

const DashboardPlaceholder: React.FC<DashboardPlaceholderProps> = ({ user, onLogout }) => {
  return (
    <div className="min-h-screen bg-slate-50">
      <nav className="bg-white border-b border-slate-200 px-8 py-4 flex justify-between items-center">
        <div className="flex items-center space-x-2">
          <div className="w-8 h-8 bg-indigo-600 rounded-md"></div>
          <span className="font-bold text-xl text-slate-800 tracking-tight">Meu Sistema</span>
        </div>
        <div className="flex items-center space-x-4">
          <span className="text-sm text-slate-600 hidden md:block">{user.email}</span>
          <button 
            onClick={onLogout}
            className="px-4 py-2 text-sm font-medium text-red-600 hover:bg-red-50 rounded-lg transition-colors border border-red-100"
          >
            Sair
          </button>
        </div>
      </nav>

      <main className="p-8 max-w-7xl mx-auto">
        <header className="mb-8">
          <h1 className="text-3xl font-bold text-slate-900">Dashboard Principal</h1>
          <p className="text-slate-500">Bem-vindo de volta! Aqui está o resumo do seu sistema.</p>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
            <h3 className="text-slate-500 text-sm font-medium uppercase mb-2">Total de Vendas</h3>
            <p className="text-3xl font-bold text-slate-900">R$ 12.450,00</p>
          </div>
          <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
            <h3 className="text-slate-500 text-sm font-medium uppercase mb-2">Novos Clientes</h3>
            <p className="text-3xl font-bold text-slate-900">42</p>
          </div>
          <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
            <h3 className="text-slate-500 text-sm font-medium uppercase mb-2">Avisos</h3>
            <p className="text-3xl font-bold text-indigo-600">3</p>
          </div>
        </div>

        <section className="mt-12 bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-200 flex justify-between items-center">
            <h2 className="font-bold text-slate-800">Atividades Recentes</h2>
            <button className="text-sm text-indigo-600 font-medium">Ver tudo</button>
          </div>
          <div className="p-0">
            <table className="w-full text-left text-sm">
              <thead className="bg-slate-50 text-slate-500 font-medium">
                <tr>
                  <th className="px-6 py-3">Ação</th>
                  <th className="px-6 py-3">Data</th>
                  <th className="px-6 py-3">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {[1, 2, 3, 4, 5].map((i) => (
                  <tr key={i} className="hover:bg-slate-50 transition-colors">
                    <td className="px-6 py-4 text-slate-700">Login realizado com sucesso</td>
                    <td className="px-6 py-4 text-slate-500">Há {i} horas atrás</td>
                    <td className="px-6 py-4">
                      <span className="px-2 py-1 bg-green-100 text-green-700 rounded-full text-xs font-medium">Completo</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      </main>
    </div>
  );
};

export default DashboardPlaceholder;
