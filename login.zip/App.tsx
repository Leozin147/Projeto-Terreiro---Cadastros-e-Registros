
import React, { useState, useEffect } from 'react';
import LoginPage from './components/LoginPage';
import { UserSession } from './types';

const App: React.FC = () => {
  const [isInitializing, setIsInitializing] = useState(true);

  useEffect(() => {
    // Verifica se já existe uma sessão salva
    const savedSession = localStorage.getItem('user_session');
    if (savedSession) {
      // Se já estiver logado, redireciona direto para o home.html
      window.location.href = 'home.html';
    } else {
      setIsInitializing(false);
    }
  }, []);

  const handleLoginSuccess = (user: UserSession) => {
    // Salva a sessão no localStorage para que o home.html possa validar se desejar
    localStorage.setItem('user_session', JSON.stringify(user));
    // Redireciona para o sistema pronto
    window.location.href = 'home.html';
  };

  if (isInitializing) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-white">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-slate-900"></div>
      </div>
    );
  }

  return (
    <LoginPage onLoginSuccess={handleLoginSuccess} />
  );
};

export default App;
