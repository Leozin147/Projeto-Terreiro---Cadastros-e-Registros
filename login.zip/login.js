
/**
 * Lógica de Login Vanilla JS
 * Sem dependências, sem compiladores.
 */

(function() {
    // 1. Verifica se já está logado ao carregar a página
    const session = localStorage.getItem('user_session');
    if (session) {
        window.location.href = 'home.html';
    }

    // Aguarda o DOM estar pronto
    document.addEventListener('DOMContentLoaded', () => {
        const loginForm = document.getElementById('loginForm');
        const errorMessage = document.getElementById('errorMessage');
        const submitBtn = document.getElementById('submitBtn');
        const btnText = document.getElementById('btnText');
        const btnLoader = document.getElementById('btnLoader');

        loginForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            // Reset de estado
            errorMessage.classList.add('hidden');
            const username = document.getElementById('username').value;
            const password = document.getElementById('password').value;

            // Interface de carregamento
            setLoading(true);

            try {
                // Simulação de delay de rede
                await new Promise(resolve => setTimeout(resolve, 800));

                // LÓGICA DE VALIDAÇÃO
                // Para integrar com Supabase real no futuro:
                // const { data, error } = await supabase.auth.signInWithPassword({ email, password })
                
                if (username === 'admin' && password === '123') {
                    // SUCESSO
                    localStorage.setItem('user_session', JSON.stringify({ 
                        user: username, 
                        loginTime: new Date().toISOString() 
                    }));
                    
                    // Redireciona para o seu sistema pronto
                    window.location.href = 'home.html';
                } else {
                    // ERRO
                    throw new Error('Credenciais inválidas');
                }

            } catch (error) {
                errorMessage.classList.remove('hidden');
                setLoading(false);
            }
        });

        function setLoading(isLoading) {
            if (isLoading) {
                submitBtn.disabled = true;
                btnText.classList.add('hidden');
                btnLoader.classList.remove('hidden');
            } else {
                submitBtn.disabled = false;
                btnText.classList.remove('hidden');
                btnLoader.classList.add('hidden');
            }
        }
    });
})();
